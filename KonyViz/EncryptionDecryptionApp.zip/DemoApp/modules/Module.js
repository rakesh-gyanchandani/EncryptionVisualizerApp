var AESKey = "ABCDEFGHIJKLMNOP";
var algo = "aes";
var prptobj = {padding:"pkcs5", mode:"ecb"};

/**
** returns plainText from encrypted using AES 128 algorithm
** AES is symmetric algorithm
*/
function decrypt(cipherText) {
  //pass key in wordArray format.
  var key = CryptoJS.enc.Utf8.parse(AESKey);
  var stringifyCipher = JSON.stringify({'ct':cipherText});
  var myClearText = kony.crypto.decrypt(algo, key, stringifyCipher, prptobj);
  return myClearText;
}

/**
** returns Base64 encoded cipherText using AES 128 algorithm.
** AES is symmetric algorithm
*/
function encrypt(plainText) {
  //pass key in wordArray format.
  var key = CryptoJS.enc.Utf8.parse(AESKey);
  var myEncryptedText = kony.crypto.encrypt(algo, key, plainText, prptobj);
  return (JSON.parse(myEncryptedText).ct);
}

//Generates random
function randomString(length) {
    var chars = "0123456789";
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}