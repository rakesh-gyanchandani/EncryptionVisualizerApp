define([],function(){
	var mappings = {
		"CardID" : "CardID",
		"CardNumber" : "CardNumber",
		"Address" : "Address",
		"CardHolder" : "CardHolder",
		"CreatedBy" : "CreatedBy",
		"LastUpdatedBy" : "LastUpdatedBy",
		"CreatedDateTime" : "CreatedDateTime",
		"LastUpdatedDateTime" : "LastUpdatedDateTime",
		"SoftDeleteFlag" : "SoftDeleteFlag",
	};
	Object.freeze(mappings);
	
	var typings = {
		"CardID" : "number",
		"CardNumber" : "string",
		"Address" : "string",
		"CardHolder" : "string",
		"CreatedBy" : "string",
		"LastUpdatedBy" : "string",
		"CreatedDateTime" : "date",
		"LastUpdatedDateTime" : "date",
		"SoftDeleteFlag" : "boolean",
	}
	Object.freeze(typings);
	
	var primaryKeys = [
					"CardID",
	];
	Object.freeze(primaryKeys);
	
	var config = {
		mappings : mappings,
		typings : typings,
		primaryKeys : primaryKeys,
		serviceName : "BankOS",
		tableName : "CreditCardInfo"
	};
	Object.freeze(config);
	
	return config;
})
