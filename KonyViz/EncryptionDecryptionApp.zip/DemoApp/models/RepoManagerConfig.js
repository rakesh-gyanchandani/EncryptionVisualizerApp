define([],function(){
	var repoMapping = {
		CreditCardInfo  : {
			model : "BankOS/CreditCardInfo/Model",
			config : "BankOS/CreditCardInfo/MF_Config",
			repository : "",
		},
	};
	
	return repoMapping;
})