ALTER TABLE `CreditCardInfo`
	MODIFY `Address` VARCHAR(1000);
