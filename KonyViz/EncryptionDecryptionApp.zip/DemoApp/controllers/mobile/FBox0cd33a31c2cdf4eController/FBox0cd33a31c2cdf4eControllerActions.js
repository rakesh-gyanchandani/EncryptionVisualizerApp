define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchStart defined for Label0d677362d081b43 **/
    AS_Label_bb4f3b8e133f4111a17d5acad5adb580: function AS_Label_bb4f3b8e133f4111a17d5acad5adb580(eventobject, x, y, context) {
        var self = this;
    }
});