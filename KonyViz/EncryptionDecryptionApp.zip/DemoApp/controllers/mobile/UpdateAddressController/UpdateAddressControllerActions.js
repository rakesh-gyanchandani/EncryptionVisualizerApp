define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0a566fdec53a945 **/
    AS_Button_ga2424f09f7249e6ad37c2e71fb20328: function AS_Button_ga2424f09f7249e6ad37c2e71fb20328(eventobject) {
        var self = this;
        return self.updateAddress.call(this);
    }
});