define({ 

 updateAddress: function () {
                      function commandCallback(status, response, error) {
                              if (status == kony.mvc.constants.STATUS_SUCCESS) {
                                  alert(JSON.stringify(response));
                              }
                        }
                        //importing creditCardInfo model defination which exposes update method for object.
                        var creditCardInfoModel = kony.mvc.MDAApplication.getSharedInstance().modelStore.getModelDefinition("CreditCardInfo");
                        //creating instance of creditCardInfo model object.
                        //model object contains primary key and data to be updated for object.
                        var creditCardInfoObject = new creditCardInfoModel( {'CardID' :  parseInt(this.view.txtCardID.text)});
                        //setting address field of creditCardInfo model.
                        creditCardInfoObject.Address = this.view.txtAddress.text;
                        //invoking update method of creditCardInfo object using model.
                        creditCardInfoObject.update(commandCallback.bind(this), {'access' : 'online'});
 				},
  
  onNavigate: function(selectedRow) {
  				this.view.txtAddress.text = selectedRow.Address;
    			this.view.txtCardID.text = selectedRow.CardID
			}

 });