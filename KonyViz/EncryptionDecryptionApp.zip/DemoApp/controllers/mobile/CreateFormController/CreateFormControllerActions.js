define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0i50acd51216740 **/
    AS_Button_e27c19a77ddf4adcb378a34cb85a817a: function AS_Button_e27c19a77ddf4adcb378a34cb85a817a(eventobject) {
        var self = this;
        return self.create.call(this);
    }
});