define({ 

  create: function() {
                   function commandCallback(status, response, error) {
                      if (status == kony.mvc.constants.STATUS_SUCCESS) {
                       alert(JSON.stringify(response));
                     }
                   }
    
                  //importing creditCardInfo model defination which exposes create method for object.
                  var creditCardInfoModel = kony.mvc.MDAApplication.getSharedInstance().modelStore.getModelDefinition("CreditCardInfo");
                  //creating instance of creditCardInfo model object.
                  //model object contains data for create operation.
                  var creditCardInfoObject = new creditCardInfoModel();
                  //setting data for address field in creditCardInfo object.
                  creditCardInfoObject.Address = this.view.txtAddress.text;
                  //setting data for CardHolder field in creditCardInfo object.
                  creditCardInfoObject.CardHolder = this.view.txtName.text;
                  //setting data for CardNumber field in creditCardInfo object.
    			  creditCardInfoObject.CardNumber = randomString(16);
                  //invoking create operation for creditCardInfo object using model.
                  creditCardInfoObject.save(commandCallback.bind(this), {'access' : 'online'});
  			}

 });