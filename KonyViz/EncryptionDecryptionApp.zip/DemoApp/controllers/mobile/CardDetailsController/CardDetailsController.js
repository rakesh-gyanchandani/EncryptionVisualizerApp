define({ 
  
  getCreditCardDetails: function() {
                      function commandCallback(status, response, error) {
                            if (status == kony.mvc.constants.STATUS_SUCCESS) {
                              this.view.segData.data = response;
                            }
                      }
    					
                      //importing creditCardInfo model defination which exposes get method for object.
                      var creditCardInfoModel = kony.mvc.MDAApplication.getSharedInstance().modelStore.getModelDefinition("CreditCardInfo");
                      //invoking get method for creditCarddInfo object using model.
                      creditCardInfoModel.getAll(commandCallback.bind(this), {'access' : 'online'});
                    },
  
  /**
** used for registering pre and post processors for CreditCardInfo object.
**/
registerProcessor : function() {
  					var self = this;
  
                    function preProcessor(value, context) {
                        if(context.metadata.enableEncryption === "true" && context.metadata.encryptionAlgorithm === "AES") {
                              value = encrypt(value);
                        }
                        return value;
                    }

                    function postProcessor(value, context) {
                        if(context.metadata.enableEncryption === "true" && context.metadata.encryptionAlgorithm === "AES") {
                              value = decrypt(value);
                        }
                        return value;
                    }

                    var creditCardInfoModel = kony.mvc.MDAApplication.getSharedInstance().modelStore.getModelDefinition("CreditCardInfo");

                    function registrationSuccess() {
                        kony.print("Registration Success");
                        self.getCreditCardDetails();
                    }

                    function registrationFailure(err) {
                      kony.print("Registration Failure" + JSON.stringify(err));
                    }

                    var options = {"preProcessor" : preProcessor, 'postProcessor': postProcessor};
                    creditCardInfoModel.registerProcessors(options, registrationSuccess, registrationFailure);

              }

 });