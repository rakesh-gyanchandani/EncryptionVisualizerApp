define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0b456f8850b6247 **/
    AS_Button_a2517fbb83ca4259a24205bb58b94f9e: function AS_Button_a2517fbb83ca4259a24205bb58b94f9e(eventobject) {
        var self = this;
        return self.getCreditCardDetails.call(this);
    },
    /** onRowClick defined for segData **/
    AS_Segment_j4d43838081c4c9b897f5f385fb9349c: function AS_Segment_j4d43838081c4c9b897f5f385fb9349c(eventobject, sectionNumber, rowNumber) {
        var self = this;
        var selectedData = this.view.segData.data[rowNumber];
        var nav = new kony.mvc.Navigation("UpdateAddress");
        nav.navigate(selectedData);
    },
    /** onClick defined for Button0gb1ed063710746 **/
    AS_Button_cce7a40394724dd2a2b14aaded20e0ad: function AS_Button_cce7a40394724dd2a2b14aaded20e0ad(eventobject) {
        var self = this;
        var nav = new kony.mvc.Navigation("CreateForm");
        nav.navigate();
    },
    /** postShow defined for CardDetails **/
    AS_Form_a1920b9dd6184a4ba997ed4a85b594f1: function AS_Form_a1920b9dd6184a4ba997ed4a85b594f1(eventobject) {
        var self = this;
        return self.registerProcessor.call(this);
    }
});